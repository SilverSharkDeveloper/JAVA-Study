package exception;

public class MyException extends Exception{
public MyException() {
	super("음수 입력하면 안됨!!");
}
}
