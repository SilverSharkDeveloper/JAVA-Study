package arrayTest;

public class ArrayTest2 {
	public static void main(String[] args) {
		int[ ] arData = new int [40];
		
		for(int i = 0 ; i <arData.length ; i++) {
			arData[i] = i+1;
		}
		for(int i = 0; i<arData.length ; i++) {
			System.out.println(arData[i]);	
			
			
	
		}
	}
}
