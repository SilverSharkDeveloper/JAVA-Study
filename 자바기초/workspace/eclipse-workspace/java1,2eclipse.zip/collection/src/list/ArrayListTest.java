package list;

import java.util.ArrayList;
import java.util.List;

public class ArrayListTest {
	public static void main(String[] args) {
//		ArrayList al = new ArrayList();
//		al.add(3);
//		al.add(4.5);
//		al.add("String");
//		
//		for(int i = 0; i<al.size(); i++) {
//			System.out.println(al.get(i));
//		}
		ArrayList<Integer> list = new ArrayList<>();
//		list.add(10);
//		list.add()
		for(int i =0 ; i <10 ; i++) {
			list.add((10-i)*10);
		}
	//항상(빠른)for문, forEach문
		//index번호가 필요없다.
		for(int data : list) {
				System.out.println(data);
		}
		for(int t : new int[] {1,2,3,4,5,}) {
			System.out.println(t);
		}
		System.out.println(list);
		List<Integer> list2 = new ArrayList<>();
		
	}
}
