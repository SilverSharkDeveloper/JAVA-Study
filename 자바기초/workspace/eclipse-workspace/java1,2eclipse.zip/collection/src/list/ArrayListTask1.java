package list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class ArrayListTask1 {
	public static void main(String[] args) {
		Random r = new Random();
		List<Integer> list = new ArrayList<>();
		
		int tmp = 0 ;
		
		for(int i = 0 ; i <5; i++) {
			
		tmp =	r.nextInt(20)+1;
		
		if(!list.contains(tmp)) {
			list.add(tmp);
			continue;
		}
		i--;
			
		}
		Collections.sort(list);
		
		System.out.println(list);
	}
}
