package listTask;

import java.util.ArrayList;
import java.util.List;

public class UserService {
	private List<UserVO> userList = new ArrayList<>();
	//id중복검사
	public boolean checkId(String id) {
		for(UserVO user : userList) {
			if(user.getId().equals(id)) {
				return false;
			}
		}
		return true;
	}
	//회원가입
	public void join(UserVO user) {
		userList.add(user);
	}
	//로그인
	public UserVO login(String id, String pw) {
		for(UserVO user : userList) {
			if(user.getId().equals(id)&&user.getPw().equals(pw)) {
				return user;
			}
		}
		return null;
	}
}
