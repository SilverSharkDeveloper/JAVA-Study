package methodTask;

public class Exam03 {
	public static void main(String[] args) {
		Student 철수 = new Student();
		Student 유리 = new Student();
		철수.eng = 30;
		
		System.out.println(철수);
		System.out.println(유리);
	}
}
