package methodTask;

public class Student {
	int math;
	int eng;
	int kor;
	double avg;
	String grade;
	
public Student() {
	// TODO Auto-generated constructor stub
}
	int getTotal() {
		return math + eng + kor;
	}
}
