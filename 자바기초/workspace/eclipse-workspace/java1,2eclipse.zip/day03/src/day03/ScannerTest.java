package day03;

public class ScannerTest {

}
