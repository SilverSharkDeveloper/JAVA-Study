package lambda;

@FunctionalInterface
public interface FunctionalInter2 {
	int add10(int number);
}
