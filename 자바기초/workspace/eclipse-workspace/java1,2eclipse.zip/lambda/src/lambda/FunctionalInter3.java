package lambda;
@FunctionalInterface
public interface FunctionalInter3 {
	int method(int a, int b);
}
