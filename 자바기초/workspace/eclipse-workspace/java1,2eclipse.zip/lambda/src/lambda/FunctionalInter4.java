package lambda;

@FunctionalInterface
public interface FunctionalInter4 {
	void combineString (String a, String b);
}
