package lambda;
@FunctionalInterface
public interface FunctionalInter {
void method();
}
