package lambdaTest;

@FunctionalInterface

public interface SubInter {
	String MySubString(String st1, String str2);
}
