package lambdaTest;

public class Main {
	public static void main(String[] args) {
	int result =	Main.calculator(false).multiplyNumber(5, 6);
	System.out.println(result);
	}
	
	public static MultipleInter calculator (boolean isTrue) {
		if(isTrue) {
//			 MultipleInter m = (n1,n2) -> n1*n2;
		     	return (n1,n2) -> n1*n2;
			
		}else {
			return (n1,n2) -> 0;
		}
	}
}
