package lambdaTest;

@FunctionalInterface
public interface MultipleInter {
	int multiplyNumber(int num1, int num2);
}
