package forTest;

public class ForTest1 {
public static void main(String[] args) {
	for(int i=0; i <3; ++i) {
		System.out.println("안녕");
	}
}
}
