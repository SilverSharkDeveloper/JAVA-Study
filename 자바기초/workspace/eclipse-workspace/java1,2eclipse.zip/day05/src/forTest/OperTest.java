package forTest;

public class OperTest {
	public static void main(String[] args) {
		int a =0;
		a+=1 ;
		System.out.println(++a);
		
	}
}
