package forTest;

public class ForTest2 {
public static void main(String[] args) {
	//이름 10번 출력
	for(int i = 0; i <10 ; ++i) {
		System.out.println("허은상");
	}
	
	for (int i = 0; i<10 ; ++i) {
	
		System.out.println((i+1) + ".허은상");
	}
	
}


}
