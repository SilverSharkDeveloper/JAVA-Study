package forTest;

public class ForTest3 {
public static void main(String[] args) {
	for(int i =0; i > -10; i-- ) {
		System.out.println((i+10)+"허은상");
		
	}
		for (int i =0 ; i <10; i++) {
			System.out.println((10-i) + "허은상");
		}
}
}
