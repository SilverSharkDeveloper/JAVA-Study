package whileTest;

public class WhileTest {
	public static void main(String[] args) {
	
		int cnt= 0;
	
		while(cnt<10) {
			
			System.out.println(cnt +1);
			cnt++;
			
		}
}
}
