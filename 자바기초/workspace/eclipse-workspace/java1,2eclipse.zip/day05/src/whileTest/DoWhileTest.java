package whileTest;

public class DoWhileTest {
public static void main(String[] args) {
	boolean isTrue = false;
	
		while(isTrue) {
			System.out.println("while문이다.");
		}
		
		
		do {
			System.out.println("do ~ while문이다");
		}while(isTrue);
}
}
