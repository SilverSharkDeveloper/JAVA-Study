package anonymousTest;

public interface InterA {
void printData();
}
