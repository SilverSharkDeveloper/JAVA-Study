package anonymousTest;

public class ClassA implements InterA{
@Override
public void printData() {
System.out.println("ㅎㅇ");	
}
}
