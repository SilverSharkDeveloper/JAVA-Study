package anonymousTest;

public class Main {
public static void main(String[] args) {
	ClassA ca = new ClassA();
	ca.printData();
	
	InterA a = new InterA() {
		
		@Override
		public void printData() {
			System.out.println("바보");
		}
	};
	
}
}
