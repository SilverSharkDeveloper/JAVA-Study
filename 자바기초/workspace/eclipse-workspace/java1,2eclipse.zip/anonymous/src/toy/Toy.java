package toy;

public interface Toy {
	String[] speakList();
	void pushBtn(String speak);
}
