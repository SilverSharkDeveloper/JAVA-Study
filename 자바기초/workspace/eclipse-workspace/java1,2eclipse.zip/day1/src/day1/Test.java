package day1;

public class Test {
		public static void main(String[] args) {
				System.out.println(1+2);
					float a;
					a = 2.2f;
					System.out.println(a+3);
							System.out.println(1==1.0);
						System.out.println(1!=1);
		}

}
	