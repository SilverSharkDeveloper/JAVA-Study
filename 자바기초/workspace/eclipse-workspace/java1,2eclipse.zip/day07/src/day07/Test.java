package day07;

public class Test {
	
	void printHello() {
		System.out.println("안녕하세요");
	}
	
	public static void main(String[] args) {
	Test t = new Test();
	t.printHello();
	}
	
	
	
	

}
