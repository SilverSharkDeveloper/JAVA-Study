package inter;

public interface Inter {
	int var1 = 20;
	void method1();
	void method12();
	
}
