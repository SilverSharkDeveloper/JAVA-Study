package randomTest;

import java.util.Random;

public class RandomTest {

	public static void main(String[] args) {
		Random r = new Random();					//ctrl shift o 
	System.out.println(r.nextInt(10));
	
	}

}
