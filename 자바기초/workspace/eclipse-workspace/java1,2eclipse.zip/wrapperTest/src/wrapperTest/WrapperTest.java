package wrapperTest;

public class WrapperTest {
	public static void main(String[] args) {
		
		//boxing
		Integer numInt = new Integer(3);  //생성자로 하는건 추천하지않음 deprecated
		Integer numInt2 = Integer.valueOf(3);
		Double numD = Double.valueOf(3.14);
		//unboxing
		int num	= numInt.intValue();
		
		//auto boxing
		Integer numInt3 = 3;
		//auto unboxing
		int num2 = numInt3;
		System.out.println(num2);
		
	}
}
