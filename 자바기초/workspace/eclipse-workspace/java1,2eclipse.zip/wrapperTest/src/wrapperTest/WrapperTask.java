package wrapperTest;

import java.util.Arrays;

class A {
	
}
public class WrapperTask {
	public static void main(String[] args) {
		Object [] ob = {1, 3.14, 'A',"Dog",true};
			System.out.println(Arrays.toString(ob));
		
		
	}
}
