package mytest;

public class MethodTest {
	static String method(int a){
		return "s" + a;
		
	}
	public static void main(String[] args) {
		System.out.println(method(4));
	}
}
