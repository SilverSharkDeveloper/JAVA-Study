package mytest;

public class MyTest2 {
	
					public static String numbering ( int start, int finish) {
						String output = "";
						for(int i = start ; i<=finish; ++i) {
						
							output += i ;
							
				
							
						}
						return output;
					}
				public static void main(String[] args) {
					String result = numbering(10,18);
					System.out.println(result);
					int a ;
					a = 3;
					switch(a) {
					case 1: 
							
					}
					
				}
}
