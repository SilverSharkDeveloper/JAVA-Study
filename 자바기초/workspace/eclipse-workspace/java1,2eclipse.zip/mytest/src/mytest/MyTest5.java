package mytest;

public class MyTest5 {
	public static void main(String[] args) {
		
	}
}
