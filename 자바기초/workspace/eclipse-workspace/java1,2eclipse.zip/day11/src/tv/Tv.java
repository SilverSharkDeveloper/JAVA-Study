package tv;

public class Tv {
	int ch;
	int vol;	
	boolean power;
	
	void chUp(){}
	void chDown(){}
}
