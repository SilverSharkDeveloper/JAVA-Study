package tv;

public class SmartTv extends Tv2{
	void netfilx() {}
}
