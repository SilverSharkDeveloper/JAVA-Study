package tv;

public class Main {
	public static void main(String[] args) {
	 Tv tv = new Tv();
	 tv.chDown();
	 Tv2 tv2 = new Tv2();
	 tv2.mode();
	 SmartTv sTv = new SmartTv();
	 sTv.netfilx();
	 
	}
}
