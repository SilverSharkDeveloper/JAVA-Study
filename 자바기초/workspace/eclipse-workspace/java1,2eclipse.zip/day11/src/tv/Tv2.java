package tv;

public class Tv2 extends Tv{
	void mode()	{
		
	}
}
