package person;

public class Employee extends Person {
	int employeeNumber;
	
}
