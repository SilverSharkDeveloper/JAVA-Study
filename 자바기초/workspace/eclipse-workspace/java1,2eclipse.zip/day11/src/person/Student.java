package person;

public class Student extends Person{
	void study() {}
	
}
