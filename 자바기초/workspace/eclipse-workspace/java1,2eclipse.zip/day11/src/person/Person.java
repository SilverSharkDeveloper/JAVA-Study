package person;

public class Person {
	int age;
	String name;
	void eat() {}
	void sleep() {}
	
}
