package parents;

public class Parents {
	int number;
	
	public Parents(int number) {
		super();
		this.number = number;
	}

	public Parents() {
		System.out.println("Parents 생성자 호출");
	}
}
