package access;

public class Main {
	public static void main(String[] args) {
		A a = new A();
		a.var1 = 3;
		a.var2 = 3;							
		a.var3 = 3;
//		a.var4 = 4;			//객체를 만들어도 사용할 수 없다. 
		
	}
}
