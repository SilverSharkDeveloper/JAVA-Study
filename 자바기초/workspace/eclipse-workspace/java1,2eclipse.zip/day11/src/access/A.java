package access;
	


public class A {
	public int var1;
	int var2;
	protected int var3;
	private int var4;
	
	public int getVar4() {
		return var4;
	}
	public void setVar4(int var4) {														//alt shift o r
		this.var4 = var4;
	}
	
//	public void setVar4(int var4) {
//		this.var4 = var4;
//	}
//	public int getVar4() {
//		return this.var4;
//	}
}
