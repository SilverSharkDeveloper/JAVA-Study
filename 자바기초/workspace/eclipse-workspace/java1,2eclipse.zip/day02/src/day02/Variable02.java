package day02;

public class Variable02 {
	public static void main(String[] args) {
		int num1 = -3;
		long num2 = 3L;
		float num3 = 3.0f;
		double num4 = 3.14;
		char alpha	= 'a';
		boolean isTrue	=	true;
		String str = "올때 메로나";
		
		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);
		System.out.println(num4);
		System.out.println(alpha);
		System.out.println(isTrue);
		System.out.println(str);
	}
}
