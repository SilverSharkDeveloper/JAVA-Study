package day02;

public class Vriable01 {
	public static void main(String[] args) {
		int a; //정수를 저장할 수 있는 변수 a를 선언했다.(만들었다)
		a = 3; //변수 a에 3이라는 정수 값을 저장했다.
		int b = 4;//변수 b를 선언과 동시에 4라는 값으로 초기화 하였다.
		System.out.println(a);
		System.out.println(b);
		
		int c, d = 5, e=11; //여러 변수를 선언
		System.out.println(d);
		System.out.println(e);
		
			
	}
}
