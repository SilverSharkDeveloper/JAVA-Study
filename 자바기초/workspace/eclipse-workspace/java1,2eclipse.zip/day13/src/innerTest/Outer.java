package innerTest;

public class Outer {
	int var1;
	String var2;
	
	void method() {
		class Test{
			
		}
	}
	class Inner{
		void innerMethod() {}
		
	}
}
