package fan;

public abstract class FanAdapter implements Fan{
	@Override
	public void turbo() {
		
	}
}
