package test;

public class ClassB extends ClassA implements Inter1{

}
