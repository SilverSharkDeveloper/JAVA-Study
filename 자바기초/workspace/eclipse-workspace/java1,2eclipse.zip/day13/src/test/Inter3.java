package test;

public interface Inter3 {
default void printText() {
	System.out.println("Inter3");
}
}
