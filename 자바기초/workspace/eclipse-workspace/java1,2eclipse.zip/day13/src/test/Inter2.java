package test;

public interface Inter2 {
default void printText() {
	System.out.println("Inter2");
}
}
