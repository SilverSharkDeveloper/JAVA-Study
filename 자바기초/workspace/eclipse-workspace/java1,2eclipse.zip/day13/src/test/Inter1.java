package test;

public interface Inter1 {
	default void printText() {
		System.out.println("inter1");
	}
}
