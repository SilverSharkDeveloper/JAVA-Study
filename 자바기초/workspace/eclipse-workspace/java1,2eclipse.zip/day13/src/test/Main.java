package test;

public class Main {
public static void main(String[] args) {
	ClassB b = new ClassB();
	
	b.printText();
	
	Test t = new Test();
	t.printText();
}
}
