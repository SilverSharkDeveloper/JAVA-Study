package test;

public class ClassA {
	public void printText()	{
		System.out.println("ClassA");
	}
}
