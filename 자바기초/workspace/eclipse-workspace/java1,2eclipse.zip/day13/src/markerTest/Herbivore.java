package markerTest;

public class Herbivore extends Animal{

}
