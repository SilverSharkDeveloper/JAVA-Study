package markerTest;

public class Animal {

}
