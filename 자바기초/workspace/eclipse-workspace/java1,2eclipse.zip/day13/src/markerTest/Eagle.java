package markerTest;

public class Eagle extends Carnivore implements Sky{

}
