package markerTest;

public class Carnivore extends Animal{

}
