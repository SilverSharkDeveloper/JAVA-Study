package markerTest;

public interface Sky {

}
