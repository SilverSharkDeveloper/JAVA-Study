package markerTest;

public class Horse extends Herbivore implements Land{

}
