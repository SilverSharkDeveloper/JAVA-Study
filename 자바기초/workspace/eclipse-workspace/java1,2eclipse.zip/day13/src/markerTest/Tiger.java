package markerTest;

public class Tiger extends Carnivore implements Land{

}
