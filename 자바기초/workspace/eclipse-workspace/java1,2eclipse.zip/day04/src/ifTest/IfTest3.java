package ifTest;

public class IfTest3 {
public static void main(String[] args) {
	int num=124;
	
	if(num==1) {
		System.out.println("1이다");
		
	}else if (num==2) {
		System.out.println("2다.");
	}else if (num==3) {
		System.out.println("3이다.");
		
	}else if(num==4) {
		System.out.println("4이다");
		
	}else {
		System.out.println("1~4가 아니다.");
	}
}
}
