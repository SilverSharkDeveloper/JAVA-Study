package ifTest;

public class IfTest2 {
public static void main(String[] args) {
	int num1 = 30, num2=20;
	if(num2>num1) {
		System.out.println("num2가 크다");
		
	}else {
		System.out.println("num1이 크다");
		
	}
}
}
